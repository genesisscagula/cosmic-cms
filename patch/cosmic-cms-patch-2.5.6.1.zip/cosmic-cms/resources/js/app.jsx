import '../css/app.css';
import './bootstrap';

import { createInertiaApp } from '@inertiajs/react';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { createRoot } from 'react-dom/client';
import CosmicNotification from './Components/CosmicNotification';
import { CreditBalanceProvider } from './Components/CosmicCredits/CreditBalanceContext';

const appName = import.meta.env.VITE_APP_NAME || 'Laravel';

createInertiaApp({
    title: (title) => `${title} - ${appName}`,
    resolve: (name) =>
        resolvePageComponent(
            `./Pages/${name}.jsx`,
            import.meta.glob('./Pages/**/*.jsx'),
        ),
    setup({ el, App, props }) {
        const root = createRoot(el);

        const initialBalance = props.initialPage?.props?.auth?.creditBalance ?? 0;

        root.render(
            <CreditBalanceProvider initialBalance={initialBalance}>
                <App {...props} />
                <CosmicNotification />
            </CreditBalanceProvider>,
        );
    },
    progress: {
        color: '#4B5563',
    },
});
