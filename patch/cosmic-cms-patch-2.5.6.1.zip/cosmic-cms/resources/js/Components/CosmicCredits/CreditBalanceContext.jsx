import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { router } from '@inertiajs/react';

const CreditBalanceContext = createContext(null);

function normalizeBalance(value, fallback = 0) {
    const numericValue = Number(value);
    return Number.isFinite(numericValue) ? numericValue : fallback;
}

export function CreditBalanceProvider({ children, initialBalance = 0 }) {
    const [balance, setBalanceState] = useState(() => normalizeBalance(initialBalance));

    const setBalance = useCallback((nextBalance) => {
        setBalanceState((currentBalance) => normalizeBalance(nextBalance, currentBalance));
    }, []);

    useEffect(() => {
        // Keep the global wallet in sync after every Inertia navigation/refresh.
        const removeListener = router.on('success', (event) => {
            const nextBalance = event.detail?.page?.props?.auth?.creditBalance;

            if (nextBalance !== null && nextBalance !== undefined) {
                setBalance(nextBalance);
            }
        });

        return removeListener;
    }, [setBalance]);

    const value = useMemo(() => ({ balance, setBalance }), [balance, setBalance]);

    return (
        <CreditBalanceContext.Provider value={value}>
            {children}
        </CreditBalanceContext.Provider>
    );
}

export function useCreditBalance() {
    const context = useContext(CreditBalanceContext);

    if (!context) {
        throw new Error('useCreditBalance must be used inside CreditBalanceProvider.');
    }

    return context;
}
