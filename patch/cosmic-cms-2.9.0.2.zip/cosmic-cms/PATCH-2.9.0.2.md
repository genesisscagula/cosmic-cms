# Cosmic CMS 2.9.0.2 — Real Hero Parallax Hotfix

## Fixed

- Increased the background travel distance so the parallax motion is immediately visible.
- Added an opposing, subtler content movement for stronger cinematic depth.
- Added a gentle content fade during scroll.
- Fixed the effect inside the Builder by listening to nested scroll containers, not only the browser window.
- Added reduced-motion support.
- Updated static export to match the Builder effect.

## Preserved

This patch intentionally excludes `.env`, `database/database.sqlite`, `storage`, `vendor`, and `node_modules`.
