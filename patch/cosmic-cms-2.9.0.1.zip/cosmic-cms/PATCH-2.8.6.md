# Cosmic CMS Patch 2.8.6

## Enhancement 1 — AI blog formatting and modal layering
- AI blog content now requests semantic HTML rather than one continuous plain-text block.
- Server-side normalization converts plain-text fallback responses into headings and paragraphs.
- Client-side normalization provides an extra safeguard before generated content enters the rich-text editor.
- Blog AI prompt, confirmation, and editor dialogs now render through a React portal attached to `document.body`.
- Modal layers use application-high z-index values so the builder toolbar can no longer cover the popup.

## Enhancement 2 — Non-branded AI image selection
- AI now returns a short generic `image_query` specifically for stock-photo search.
- The prompt explicitly forbids company names, product names, logos, trademarks, watermarks, branded interfaces, and recognizable platform screenshots.
- Unsplash candidates are rejected when their metadata contains common platform/brand terms or branding-related keywords.
- Smart-image cache namespace was bumped to v3 so previously cached branded results are not reused.
