# Cosmic CMS v2.8.6.1

## Blog Builder Polish & Workflow Fixes

### Single post typography
- Added 20px bottom spacing to rendered article paragraphs.
- Added clearer spacing for H2, H3, lists, and blockquotes.
- Improved long-form article readability without changing saved content.

### Modal close controls
- Increased blog AI and blog editor close buttons to a 36px click target.
- Added a visible border, hover background, and larger close icon.

### AI-generated single post refresh
- Fixed stale single-post previews after AI regeneration.
- Updated posts now sync immediately into the currently viewed single-post state.
- Manual saves use the same immediate preview synchronization.

### Blog card delete action
- Added a right-aligned Delete post action beside View and Edit.
- Added the action to regular cards and the featured post card.
- Uses the Cosmic confirmation modal instead of a browser confirm dialog.
- Deleted cards are removed immediately through the existing blog callback.
- Added a short success notification after deletion.
