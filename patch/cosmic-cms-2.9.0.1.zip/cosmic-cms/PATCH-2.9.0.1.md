# Cosmic CMS v2.9.0.1 — Hero Parallax

## Added
- New premium `hero_parallax` Spark.
- Smooth scroll-driven background depth using requestAnimationFrame.
- Editable eyebrow, heading, description, two CTA buttons, image, and scroll label.
- Adjustable overlay opacity, parallax strength, alignment, and height.
- Responsive and reduced-jank transform implementation.
- Builder registry, Spark browser preview, AI schema, pricing registry, and static export support.

## Pricing
- Hero Parallax: **100 credits**
- Collection: Signature / Pro

## Safety
- No database file was modified by this patch.
