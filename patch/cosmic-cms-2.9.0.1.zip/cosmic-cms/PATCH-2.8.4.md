# Cosmic CMS Patch 2.8.4

## Fixes

### Enhancement #1 — Guest credit balance safety

- Removed `usePage()` from `CreditBalanceProvider`, because the provider is mounted outside the Inertia page context.
- Passes the initial authentication state from `app.jsx` into the provider.
- Guest pages such as `/start` no longer request `/credits/balance`.
- Silently ignores `401 Unauthorized` responses if a session expires.
- Authenticated pages continue to refresh the Cosmic Credits balance after successful Inertia navigation.

### Migration hotfix — existing `cosmic_unlocks` table

- The `cosmic_unlocks` migration now checks `Schema::hasTable()` before creating the table.
- Prevents SQLite error: `table cosmic_unlocks already exists`.
- Existing unlock data is preserved.

## After installing

```bash
php artisan migrate
php artisan optimize:clear
npm run build
```

For Vite development mode, use `npm run dev` instead of `npm run build`.
