# Cosmic CMS Patch 2.8.5

## Enhancement 1 — Global modal and blog editor polish
- Raised AI, editor, and confirmation dialogs above builder controls.
- Expanded the blog editor to `max-w-5xl` and `92vh`.
- Added reusable dark scrollbars for modal/editor overflow.
- Categories and tags now use comma-separated text inputs.
- Replaced the plain article textarea with a lightweight rich-text editor that has formatting, lists, links, quotes, undo, and redo without adding a new npm dependency.

## Enhancement 2 — Single blog post layout
- Removed the outer bordered card from the single-post view.
- Increased the post and body widths.
- Aligned “Back to all posts” with the featured image.
- Added a 15px radius to the featured image.

## Enhancement 3 — AI generation flow
- Replaced browser confirm dialogs with Cosmic-styled confirmation modals.
- Added the existing Cosmic spinner to AI generation.
- AI-generated posts now save automatically, close the dialogs, and immediately append/update the blog card.
- Errors stay inline and keep the editor open.
