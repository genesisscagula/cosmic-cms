<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
        Schema::table('websites', function (Blueprint $table) {
            // I-add ang global_footer column human sa global_header
            $table->json('global_footer')->nullable()->after('global_header');
        });
    }

    public function down(): void
    {
        Schema::table('websites', function (Blueprint $table) {
            $table->dropColumn('global_footer');
        });
    }
};
