import { useMemo, useState } from "react";
import NewWebsiteModal from "../Components/NewWebsiteModal";
import TemplateCard, { FeaturedTemplateCard } from "../Components/TemplateCard";
import TemplateEmptyState from "../Components/TemplateEmptyState";
import TemplateToolbar from "../Components/TemplateToolbar";

const templates = [
    { id: "aurora", name: "Aurora Agency", slug: "aurora-agency", category: "Business", industry: "Creative agency", description: "A complete creative-studio homepage with editable content.", themeId: "violet", pageCount: 1, tags: ["agency", "creative"], featured: true, isNew: false, updatedAt: "2026-07-22", usage: 84 },
    { id: "midnight", name: "Meridian Studio", slug: "midnight-studio", category: "Business", industry: "Professional studio", description: "A confident professional starter for strategy-led teams.", themeId: "midnight", pageCount: 1, tags: ["studio", "professional"], featured: false, isNew: true, updatedAt: "2026-07-25", usage: 0 },
    { id: "obsidian", name: "Noir Atelier", slug: "obsidian-atelier", category: "Portfolio", industry: "Luxury brand", description: "A restrained, premium foundation for high-consideration brands.", themeId: "obsidian", pageCount: 1, tags: ["luxury", "portfolio"], featured: false, isNew: true, updatedAt: "2026-07-25", usage: 0 },
    { id: "forge", name: "Forge Works", slug: "forge-works", category: "Business", industry: "Industrial services", description: "A direct, practical starter for capable service businesses.", themeId: "asphalt", pageCount: 1, tags: ["industrial", "services"], featured: false, isNew: true, updatedAt: "2026-07-25", usage: 0 },
    { id: "table", name: "Table & Tide", slug: "table-tide", category: "Restaurant", industry: "Restaurant", description: "Warm editorial menus and reservations.", themeId: "terracotta", pageCount: 5, tags: ["food", "menu"], featured: true, isNew: true, updatedAt: "2026-07-23", usage: 72 },
    { id: "form", name: "Form & Function", slug: "form-function", category: "Portfolio", industry: "Design portfolio", description: "A focused portfolio for independent makers.", themeId: "slate", pageCount: 4, tags: ["portfolio", "design"], featured: false, isNew: false, updatedAt: "2026-07-18", usage: 53 },
    { id: "luma", name: "Luma Clinic", slug: "luma-clinic", category: "Healthcare", industry: "Healthcare", description: "Clear care information and trust-building pages.", themeId: "ocean", pageCount: 7, tags: ["medical", "clinic"], featured: false, isNew: true, updatedAt: "2026-07-24", usage: 61 },
    { id: "haven", name: "Haven Estates", slug: "haven-estates", category: "Real Estate", industry: "Real estate", description: "Premium listings for modern property teams.", themeId: "emerald", pageCount: 6, tags: ["property", "homes"], featured: true, isNew: false, updatedAt: "2026-07-20", usage: 79 },
    { id: "cart", name: "Cartwright", slug: "cartwright", category: "Ecommerce", industry: "Retail", description: "A direct-to-consumer storefront foundation.", themeId: "rose", pageCount: 8, tags: ["shop", "retail"], featured: false, isNew: false, updatedAt: "2026-07-16", usage: 47 },
    { id: "orbit", name: "Orbit Launch", slug: "orbit-launch", category: "Landing Page", industry: "SaaS", description: "Conversion-ready launch pages for digital products.", themeId: "indigo", pageCount: 3, tags: ["saas", "launch"], featured: false, isNew: true, updatedAt: "2026-07-24", usage: 66 },
];

const blankTemplate = { id: "blank", name: "Blank Website", slug: "blank", category: "Start from Scratch", industry: "Blank canvas", themeId: "slate", pageCount: 1, tags: ["blank"], featured: false, isNew: false, updatedAt: "2026-07-24", usage: 0 };

export default function Templates() {
    const [query, setQuery] = useState("");
    const [category, setCategory] = useState("All");
    const [sort, setSort] = useState("featured");
    const [selectedTemplate, setSelectedTemplate] = useState(null);

    const filteredTemplates = useMemo(() => {
        const search = query.trim().toLowerCase();

        return templates
            .filter((template) => (category === "All" || template.category === category)
                && (!search || [template.name, template.category, template.industry, ...template.tags].join(" ").toLowerCase().includes(search)))
            .sort((a, b) => (sort === "recent" ? b.updatedAt.localeCompare(a.updatedAt) : sort === "used" ? b.usage - a.usage : Number(b.featured) - Number(a.featured)));
    }, [query, category, sort]);

    const action = (label, template) => console.info(label, template.id);
    const useTemplate = (template) => {
        if (["aurora-agency", "midnight-studio", "obsidian-atelier", "forge-works"].includes(template.slug)) {
            setSelectedTemplate(template);
            return;
        }

        action("Use template", template);
    };
    const featured = filteredTemplates.filter((template) => template.featured).slice(0, 2);

    return (
        <section className="space-y-7">
            <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                <div>
                    <p className="text-sm font-medium text-violet-300">Template library</p>
                    <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">Templates</h1>
                    <p className="mt-2 text-sm text-slate-400">Start with a polished foundation, then make it your own.</p>
                </div>
                <button type="button" onClick={() => console.info("Create template")} className="inline-flex h-10 items-center justify-center rounded-xl bg-white px-4 text-sm font-semibold text-slate-950 transition hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-400">Create Template</button>
            </header>

            <TemplateToolbar query={query} onQueryChange={setQuery} category={category} onCategoryChange={setCategory} sort={sort} onSortChange={setSort} />

            {featured.length > 0 && (
                <div>
                    <div className="mb-3 flex items-center justify-between"><h2 className="text-sm font-semibold text-white">Featured templates</h2><span className="text-xs text-slate-500">Curated starting points</span></div>
                    <div className="grid gap-4 xl:grid-cols-2">
                        {featured.map((template) => <FeaturedTemplateCard key={template.id} template={template} onPreview={(item) => action("Preview template", item)} onUse={useTemplate} />)}
                    </div>
                </div>
            )}

            <div>
                <div className="mb-3 flex items-center justify-between"><h2 className="text-sm font-semibold text-white">Explore templates</h2><span className="text-xs text-slate-500">{filteredTemplates.length} available</span></div>
                {filteredTemplates.length ? (
                    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                        <TemplateCard template={blankTemplate} onPreview={(item) => action("Preview template", item)} onUse={(item) => action("Use template", item)} onSave={(item) => action("Save template", item)} onDuplicate={(item) => action("Duplicate template", item)} />
                        {filteredTemplates.map((template) => <TemplateCard key={template.id} template={template} onPreview={(item) => action("Preview template", item)} onUse={useTemplate} onSave={(item) => action("Save template", item)} onDuplicate={(item) => action("Duplicate template", item)} />)}
                    </div>
                ) : <TemplateEmptyState />}
            </div>

            <NewWebsiteModal open={Boolean(selectedTemplate)} template={selectedTemplate} onClose={() => setSelectedTemplate(null)} />
        </section>
    );
}
