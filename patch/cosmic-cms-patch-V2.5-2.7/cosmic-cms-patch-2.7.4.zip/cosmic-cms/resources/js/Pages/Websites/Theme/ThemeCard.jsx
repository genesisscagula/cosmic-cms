const THEME_CREDITS = { emerald: 1, ocean: 1, indigo: 1, amber: 1, teal: 1, coffee: 2, rose: 2, forest: 2, terracotta: 2, charcoal: 2, midnight: 3, navy: 3, obsidian: 4, espresso: 4, violet: 5, ruby: 5, asphalt: 5 };

export default function ThemeCard({
    theme,
    selected,
    onSelect,
}) {
    const [primary, surface, text] = theme.colors;

    return (
        <button
            type="button"
            onClick={() => onSelect(theme.id)}
            aria-pressed={selected}
            className={`group relative overflow-hidden rounded-xl border text-left transition duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-violet-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#111113] ${
                selected
                    ? "border-violet-400/80 bg-violet-500/[0.07] shadow-[0_0_0_1px_rgba(167,139,250,0.22),0_16px_34px_rgba(0,0,0,0.28)]"
                    : "border-white/10 bg-[#171719] hover:-translate-y-0.5 hover:border-white/25 hover:bg-white/[0.035]"
            }`}
        >
            <div
                className="relative h-28 overflow-hidden border-b border-black/15 p-3"
                style={{ backgroundColor: primary }}
            >
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-black/25" />
                <div className="relative rounded-md border border-white/15 bg-black/10 p-2.5 shadow-sm">
                    <div className="h-1.5 w-12 rounded-full bg-white/70" />
                    <div className="mt-2 h-4 w-4/5 rounded-sm bg-white/85" />
                    <div className="mt-1.5 h-1.5 w-3/5 rounded-full bg-white/45" />
                    <div className="mt-3 flex gap-1.5">
                        <span className="h-4 w-8 rounded bg-white/90" />
                        <span className="h-4 w-8 rounded border border-white/45" />
                    </div>
                </div>

                {selected && (
                    <span className="absolute right-2.5 top-2.5 flex h-6 w-6 items-center justify-center rounded-full bg-violet-500 text-sm font-bold text-white shadow-lg shadow-violet-950/60">
                        ✓
                    </span>
                )}
            </div>

            <div className="p-3.5">
                <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                        <div className="truncate text-sm font-semibold text-white">
                            {theme.name}
                        </div>
                        <div className="mt-1 text-xs text-slate-400">
                            {theme.category}
                        </div>
                    </div>

                    <span className="shrink-0 rounded-full bg-violet-400/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] text-violet-300">
                        {selected ? "Active" : `⚡${THEME_CREDITS[theme.id] ?? 2}`}
                    </span>
                </div>

                <div className="mt-3 flex items-center gap-1.5" aria-label={`${theme.name} color palette`}>
                    {[primary, surface, text].map((color, index) => (
                        <span
                            key={`${color}-${index}`}
                            className="h-2.5 w-2.5 rounded-full border border-white/15"
                            style={{ backgroundColor: color }}
                        />
                    ))}
                    <span className="ml-1 text-[10px] font-medium text-slate-500">Primary · Surface · Text</span>
                </div>
            </div>
        </button>
    );
}
