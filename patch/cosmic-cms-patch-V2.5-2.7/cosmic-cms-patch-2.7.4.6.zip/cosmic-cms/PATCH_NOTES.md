# Cosmic CMS v2.7.4.6

Cumulative patch based on v2.7.4.5.

## Enhancement 3 — View Post inside Builder

- Adds **View post** actions to featured and regular saved blog cards.
- Opens a single-post reading view inside the Blog Cards block.
- Replaces only the Blog Cards content while the Blog Mini Header, Newsletter, and Latest Resources remain visible.
- Adds **Back to Blog** to return to the card grid.
- Keeps **Edit post** available from both the cards and the single-post preview.

## Enhancement 4 — Blog Image Picker + Write with AI

- Replaces the raw featured-image URL field with an image preview.
- Adds **Update Image** and **Remove** controls using the existing image upload endpoint.
- Adds a **Write with AI** prompt modal.
- AI fills title, category, tags, excerpt, article content, and an industry-aware featured image.
- Uses Website Profile context: business name, industry, business description, and location.
- Uses the industry image folder first and falls back to `default`.
- Costs 10 Cosmic Credits through the existing AI rewrite price.
- Failed AI generations refund the consumed credits.
- Generated content remains editable and does not auto-save or auto-publish.

## Included from v2.7.4.5

- Enhancement 1: Create Page cost updated to 30 Credits.
- Enhancement 2: Theme prices multiplied by 10.

## Install

Copy the `cosmic-cms` folder contents into the project root and choose **Replace All**.

Then run:

```bash
php artisan optimize:clear
npm run build
```

## Main files changed for Enhancements 3 & 4

- `app/Http/Controllers/BlogPostController.php`
- `resources/js/Pages/Websites/Blocks/Blog/BlogHubBlock.jsx`
- `routes/web.php`
