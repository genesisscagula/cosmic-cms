# Cosmic CMS Patch 2.8.3

## Enhancements

### 1. Guest credit balance requests
- CreditBalanceProvider now checks the Inertia authenticated user before requesting `/credits/balance`.
- Guest pages such as `/start` no longer produce unnecessary `401 Unauthorized` console errors.
- Credit refresh after Inertia navigation is registered only for authenticated users.

### 2. Publish failure caused by missing unlock table
- Added the `cosmic_unlocks` table and unique index to the bundled SQLite database.
- Existing migration `2026_07_30_000015_create_cosmic_unlocks_table.php` remains the source of truth for fresh installations.
- Fixes `/sparks/catalog` and publish failures caused by `no such table: cosmic_unlocks`.

### 3. Wider blog builder canvas
- Blog pages no longer use the rounded bordered "folder" frame around the page canvas.
- Blog canvas width increased from a maximum of 1560px / 86vw to 1760px / 96vw.
- Standard pages keep the existing framed builder appearance.

## After applying to an existing project

Run:

```bash
php artisan migrate
php artisan optimize:clear
npm run build
```
