<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class SmartImageService
{
    /**
     * Find a context-aware stock image, store it locally, and return its public URL.
     * Local industry/default folders are always used when the remote provider is
     * unavailable, rate-limited, misconfigured, or returns no suitable result.
     */
    public function find(string $query, string $fallbackFolder = 'default'): string
    {
        $query = $this->normalizeQuery($query);
        $fallbackFolder = Str::slug($fallbackFolder) ?: 'default';

        if ($query === '' || ! $this->remoteSearchIsConfigured()) {
            return $this->localFallback($fallbackFolder);
        }

        try {
            $cacheKey = 'cosmic-smart-image:' . sha1($query);
            $cachedPath = Cache::get($cacheKey);

            if (is_string($cachedPath) && Storage::disk('public')->exists($cachedPath)) {
                return Storage::disk('public')->url($cachedPath);
            }

            $photo = $this->searchUnsplash($query);

            if (! $photo) {
                return $this->localFallback($fallbackFolder);
            }

            $storedPath = $this->downloadUnsplashPhoto($photo, $query);

            if (! $storedPath) {
                return $this->localFallback($fallbackFolder);
            }

            Cache::put($cacheKey, $storedPath, now()->addDays(30));
            $this->triggerUnsplashDownload($photo['links']['download_location'] ?? null);

            return Storage::disk('public')->url($storedPath);
        } catch (\Throwable $exception) {
            logger()->warning('[SmartImageService] Remote image search failed; using local fallback.', [
                'query' => $query,
                'message' => $exception->getMessage(),
            ]);

            return $this->localFallback($fallbackFolder);
        }
    }

    public function localFallback(string $folder = 'default'): string
    {
        $folder = Str::slug($folder) ?: 'default';
        $files = $this->imageFiles("cms-images/{$folder}");

        if ($files->isEmpty() && $folder !== 'default') {
            $folder = 'default';
            $files = $this->imageFiles('cms-images/default');
        }

        if ($files->isEmpty()) {
            $backgroundFiles = $this->imageFiles('cms-images/background');

            if ($backgroundFiles->isNotEmpty()) {
                return Storage::disk('public')->url($backgroundFiles->random());
            }

            return 'https://picsum.photos/1600/900';
        }

        return Storage::disk('public')->url($files->random());
    }

    private function remoteSearchIsConfigured(): bool
    {
        return config('services.smart_images.provider', 'unsplash') === 'unsplash'
            && filled(config('services.unsplash.access_key'));
    }

    private function searchUnsplash(string $query): ?array
    {
        $response = Http::acceptJson()
            ->withHeaders([
                'Authorization' => 'Client-ID ' . config('services.unsplash.access_key'),
                'Accept-Version' => 'v1',
            ])
            ->connectTimeout(4)
            ->timeout(10)
            ->retry(2, 250, throw: false)
            ->get('https://api.unsplash.com/search/photos', [
                'query' => $query,
                'orientation' => 'landscape',
                'content_filter' => 'high',
                'per_page' => 8,
                'page' => 1,
            ]);

        if (! $response->successful()) {
            logger()->warning('[SmartImageService] Unsplash search was not successful.', [
                'status' => $response->status(),
                'query' => $query,
            ]);

            return null;
        }

        $results = collect($response->json('results', []))
            ->filter(fn ($photo) => is_array($photo) && filled(data_get($photo, 'urls.regular')))
            ->take(5)
            ->values();

        return $results->isEmpty() ? null : $results->random();
    }

    private function downloadUnsplashPhoto(array $photo, string $query): ?string
    {
        $url = data_get($photo, 'urls.regular');

        if (! is_string($url) || $url === '') {
            return null;
        }

        $response = Http::connectTimeout(5)
            ->timeout(20)
            ->retry(2, 300, throw: false)
            ->get($url, [
                'auto' => 'format',
                'fit' => 'crop',
                'w' => 1600,
                'q' => 82,
            ]);

        if (! $response->successful() || $response->body() === '') {
            return null;
        }

        $contentType = strtolower((string) $response->header('Content-Type'));
        $extension = match (true) {
            str_contains($contentType, 'webp') => 'webp',
            str_contains($contentType, 'png') => 'png',
            default => 'jpg',
        };

        $directory = 'cms-images/remote/' . now()->format('Y/m');
        $filename = Str::limit(Str::slug($query), 70, '') ?: 'cosmic-image';
        $path = "{$directory}/{$filename}-" . Str::lower(Str::random(10)) . ".{$extension}";

        Storage::disk('public')->put($path, $response->body());

        return Storage::disk('public')->exists($path) ? $path : null;
    }

    private function triggerUnsplashDownload(?string $downloadLocation): void
    {
        if (! is_string($downloadLocation) || $downloadLocation === '') {
            return;
        }

        try {
            Http::acceptJson()
                ->withHeaders([
                    'Authorization' => 'Client-ID ' . config('services.unsplash.access_key'),
                    'Accept-Version' => 'v1',
                ])
                ->connectTimeout(3)
                ->timeout(6)
                ->get($downloadLocation);
        } catch (\Throwable $exception) {
            logger()->notice('[SmartImageService] Unsplash download tracking failed.', [
                'message' => $exception->getMessage(),
            ]);
        }
    }

    private function imageFiles(string $directory)
    {
        return collect(Storage::disk('public')->files($directory))
            ->filter(fn ($file) => preg_match('/\.(avif|webp|png|jpe?g)$/i', $file))
            ->values();
    }

    private function normalizeQuery(string $query): string
    {
        $query = strip_tags($query);
        $query = preg_replace('/\s+/', ' ', $query) ?? '';
        $query = trim($query);

        return Str::limit($query, 140, '');
    }
}
