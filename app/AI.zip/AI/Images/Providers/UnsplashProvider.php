<?php

namespace App\AI\Images\Providers;

use App\AI\Images\Contracts\ImageProviderInterface;
use App\AI\Images\DTO\ImageSearchResult;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

final class UnsplashProvider implements ImageProviderInterface
{
    public function name(): string
    {
        return 'unsplash';
    }

    public function isEnabled(): bool
    {
        return filled(config('services.unsplash.access_key'));
    }

    public function search(string $query, array $options = []): ?ImageSearchResult
    {
        if (! $this->isEnabled()) {
            return null;
        }

        $timeout = max(1, (int) config('services.smart_images.timeout', 8));
        $startedAt = microtime(true);

        $response = Http::acceptJson()
            ->withHeaders([
                'Authorization' => 'Client-ID ' . config('services.unsplash.access_key'),
                'Accept-Version' => 'v1',
            ])
            ->connectTimeout(min(4, $timeout))
            ->timeout($timeout)
            ->retry(2, 250, throw: false)
            ->get('https://api.unsplash.com/search/photos', [
                'query' => $query,
                'orientation' => $options['orientation'] ?? 'landscape',
                'content_filter' => 'high',
                'per_page' => 12,
                'page' => 1,
            ]);

        if (! $response->successful()) {
            logger()->warning('[SmartImageProvider] Unsplash search was not successful.', [
                'provider' => $this->name(),
                'status' => $response->status(),
                'query' => $query,
                'duration_ms' => (int) round((microtime(true) - $startedAt) * 1000),
                'body' => Str::limit($response->body(), 300),
            ]);

            return null;
        }

        $results = collect($response->json('results', []))
            ->filter(fn ($photo) => is_array($photo) && filled(data_get($photo, 'urls.raw')))
            ->reject(fn (array $photo) => $this->containsBlockedBranding($photo))
            ->take(12)
            ->values();

        if ($results->isEmpty()) {
            logger()->info('[SmartImageProvider] Provider returned no usable images.', [
                'provider' => $this->name(),
                'query' => $query,
                'duration_ms' => (int) round((microtime(true) - $startedAt) * 1000),
            ]);

            return null;
        }

        // Preserve the existing relevance selection until Patch 4 introduces
        // the provider-independent ranking engine.
        $tokens = collect(preg_split('/\s+/', strtolower($query)) ?: [])
            ->filter(fn ($token) => strlen($token) >= 4)
            ->unique()
            ->values();

        $photo = $results
            ->map(function (array $photo, int $index) use ($tokens) {
                $haystack = strtolower(implode(' ', array_filter([
                    data_get($photo, 'alt_description'),
                    data_get($photo, 'description'),
                    collect(data_get($photo, 'tags', []))->pluck('title')->implode(' '),
                ])));

                $score = $tokens->sum(fn ($token) => str_contains($haystack, $token) ? 1 : 0);

                return ['photo' => $photo, 'score' => $score, 'index' => $index];
            })
            ->sortByDesc(fn ($item) => ($item['score'] * 100) - $item['index'])
            ->first()['photo'];

        $url = data_get($photo, 'urls.raw') ?: data_get($photo, 'urls.regular');

        if (! is_string($url) || $url === '') {
            return null;
        }

        logger()->info('[SmartImageProvider] Image selected.', [
            'provider' => $this->name(),
            'query' => $query,
            'duration_ms' => (int) round((microtime(true) - $startedAt) * 1000),
        ]);

        return new ImageSearchResult(
            provider: $this->name(),
            url: $url,
            description: (string) (data_get($photo, 'alt_description') ?: data_get($photo, 'description') ?: ''),
            photographer: (string) data_get($photo, 'user.name', ''),
            sourceUrl: (string) data_get($photo, 'links.html', ''),
            width: (int) data_get($photo, 'width', 0),
            height: (int) data_get($photo, 'height', 0),
            downloadParameters: [
                'auto' => 'format',
                'fit' => 'crop',
                'crop' => 'entropy',
                'w' => 1600,
                'h' => 1000,
                'q' => 82,
            ],
            meta: [
                'download_location' => data_get($photo, 'links.download_location'),
                'id' => data_get($photo, 'id'),
            ],
        );
    }

    public function trackDownload(ImageSearchResult $result): void
    {
        $downloadLocation = $result->meta['download_location'] ?? null;

        if (! is_string($downloadLocation) || $downloadLocation === '' || ! $this->isEnabled()) {
            return;
        }

        try {
            Http::acceptJson()
                ->withHeaders([
                    'Authorization' => 'Client-ID ' . config('services.unsplash.access_key'),
                    'Accept-Version' => 'v1',
                ])
                ->connectTimeout(3)
                ->timeout(6)
                ->get($downloadLocation);
        } catch (\Throwable $exception) {
            logger()->notice('[SmartImageProvider] Unsplash download tracking failed.', [
                'provider' => $this->name(),
                'message' => $exception->getMessage(),
            ]);
        }
    }

    private function containsBlockedBranding(array $photo): bool
    {
        $metadata = strtolower(implode(' ', array_filter([
            data_get($photo, 'alt_description'),
            data_get($photo, 'description'),
            data_get($photo, 'slug'),
            collect(data_get($photo, 'tags', []))->pluck('title')->implode(' '),
        ])));

        $blockedTerms = [
            'adobe', 'apple', 'canva', 'figma', 'google', 'microsoft', 'shopify',
            'squarespace', 'webflow', 'wix', 'wordpress', 'logo', 'watermark',
            'brand identity', 'branded interface', 'app screenshot', 'website builder',
        ];

        foreach ($blockedTerms as $term) {
            if (str_contains($metadata, $term)) {
                return true;
            }
        }

        return false;
    }
}
