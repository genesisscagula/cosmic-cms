<?php

namespace App\AI\Images\Contracts;

use App\AI\Images\DTO\ImageSearchResult;

interface ImageProviderInterface
{
    public function name(): string;

    public function isEnabled(): bool;

    public function search(string $query, array $options = []): ?ImageSearchResult;

    public function trackDownload(ImageSearchResult $result): void;
}
